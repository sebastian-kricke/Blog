# Angular 4 Telosys 3 Template

This is a Telosys Template for code generation.
It's purpose is to generate a full frontend rest web app after having provided a DSL model.

The generated web application is an angular 4 rest frontend and is written in TypeScript.

Check installation guide [here](https://github.com/telosys-templates-v3/typesscript-angular4-rest-frontend/wiki).